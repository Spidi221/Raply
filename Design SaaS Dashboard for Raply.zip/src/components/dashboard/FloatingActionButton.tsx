import { useState } from 'react';
import { Plus, FileText, Zap, BarChart3, X } from 'lucide-react';
import { cn } from '../ui/utils';
import { Button } from '../ui/button';
import { motion, AnimatePresence } from 'motion/react';

interface ActionItem {
  icon: React.ComponentType<any>;
  label: string;
  action: () => void;
  color: string;
}

const actions: ActionItem[] = [
  {
    icon: FileText,
    label: 'Nowy raport',
    action: () => console.log('Nowy raport'),
    color: 'bg-blue-500 hover:bg-blue-600',
  },
  {
    icon: Zap,
    label: 'Analizy AI',
    action: () => console.log('Analizy AI'),
    color: 'bg-purple-500 hover:bg-purple-600',
  },
  {
    icon: BarChart3,
    label: 'Niestandardowy panel',
    action: () => console.log('Niestandardowy panel'),
    color: 'bg-green-500 hover:bg-green-600',
  },
];

export function FloatingActionButton() {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.2 }}
            className="mb-4 space-y-3"
          >
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <motion.div
                  key={action.label}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  transition={{ delay: index * 0.05 }}
                  className="flex items-center justify-end"
                >
                  <div className="glass rounded-xl px-3 py-2 mr-3 border border-glass-border">
                    <span className="text-sm font-medium whitespace-nowrap">
                      {action.label}
                    </span>
                  </div>
                  <Button
                    size="sm"
                    className={cn(
                      "w-12 h-12 rounded-full shadow-lg transition-all duration-200 hover:scale-110",
                      action.color
                    )}
                    onClick={action.action}
                  >
                    <Icon className="w-5 h-5 text-white" />
                  </Button>
                </motion.div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main FAB */}
      <Button
        size="lg"
        className={cn(
          "w-14 h-14 rounded-full shadow-xl transition-all duration-300 hover:scale-110 neumorphic",
          "bg-gradient-to-r from-primary to-accent text-white border-0",
          isOpen && "rotate-45"
        )}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? (
          <X className="w-6 h-6" />
        ) : (
          <Plus className="w-6 h-6" />
        )}
      </Button>
    </div>
  );
}