import { useState, useEffect } from 'react';
import { Search, Clock, Star, Zap, FileText, BarChart3, Settings } from 'lucide-react';
import { cn } from '../ui/utils';
import { Dialog, DialogContent } from '../ui/dialog';
import { Badge } from '../ui/badge';

interface Command {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  category: 'navigation' | 'actions' | 'recent';
  shortcut?: string;
}

const commands: Command[] = [
  {
    id: 'dashboard',
    title: 'Przejdź do panelu głównego',
    description: 'Nawiguj do głównego panelu',
    icon: BarChart3,
    category: 'navigation',
    shortcut: '⌘D',
  },
  {
    id: 'new-report',
    title: 'Utwórz nowy raport',
    description: 'Rozpocznij tworzenie nowego raportu reklamowego',
    icon: FileText,
    category: 'actions',
    shortcut: '⌘N',
  },
  {
    id: 'ai-insights',
    title: 'Analizy AI',
    description: 'Otrzymaj rekomendacje napędzane przez AI',
    icon: Zap,
    category: 'actions',
    shortcut: '⌘I',
  },
  {
    id: 'settings',
    title: 'Ustawienia',
    description: 'Skonfiguruj swoje preferencje',
    icon: Settings,
    category: 'navigation',
    shortcut: '⌘,',
  },
];

const recentCommands = [
  'Raport Facebook Ads - Q4 2024',
  'Wyniki Google Ads',
  'Analiza kampanii Instagram',
];

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function CommandPalette({ open, onOpenChange }: CommandPaletteProps) {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);

  const filteredCommands = commands.filter(command =>
    command.title.toLowerCase().includes(query.toLowerCase()) ||
    command.description.toLowerCase().includes(query.toLowerCase())
  );

  const filteredRecent = recentCommands.filter(recent =>
    recent.toLowerCase().includes(query.toLowerCase())
  );

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        onOpenChange(!open);
      }

      if (open) {
        if (e.key === 'Escape') {
          onOpenChange(false);
        } else if (e.key === 'ArrowDown') {
          e.preventDefault();
          setSelectedIndex(i => Math.min(i + 1, filteredCommands.length + filteredRecent.length - 1));
        } else if (e.key === 'ArrowUp') {
          e.preventDefault();
          setSelectedIndex(i => Math.max(i - 1, 0));
        } else if (e.key === 'Enter') {
          e.preventDefault();
          // Handle command execution
          onOpenChange(false);
        }
      }
    };

    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, [open, onOpenChange, filteredCommands.length, filteredRecent.length]);

  useEffect(() => {
    if (open) {
      setQuery('');
      setSelectedIndex(0);
    }
  }, [open]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass border-glass-border p-0 max-w-2xl">
        <div className="flex items-center border-b border-glass-border px-4">
          <Search className="mr-2 h-4 w-4 shrink-0 opacity-50" />
          <input
            className="flex h-12 w-full rounded-md bg-transparent py-3 text-sm outline-none placeholder:text-muted-foreground disabled:cursor-not-allowed disabled:opacity-50"
            placeholder="Wpisz komendę lub szukaj..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            autoFocus
          />
          <Badge variant="outline" className="ml-2">
            ESC
          </Badge>
        </div>

        <div className="max-h-96 overflow-y-auto p-4">
          {/* Recent */}
          {filteredRecent.length > 0 && query === '' && (
            <div className="mb-6">
              <h4 className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider flex items-center">
                <Clock className="w-3 h-3 mr-2" />
                Ostatnie
              </h4>
              <div className="space-y-1">
                {filteredRecent.map((recent, index) => (
                  <div
                    key={recent}
                    className={cn(
                      "flex items-center rounded-lg px-3 py-2 text-sm cursor-pointer transition-colors",
                      index + filteredCommands.length === selectedIndex
                        ? "bg-accent text-accent-foreground"
                        : "hover:bg-accent/50"
                    )}
                  >
                    <FileText className="mr-3 h-4 w-4 opacity-50" />
                    <span>{recent}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Commands */}
          {filteredCommands.length > 0 && (
            <div>
              <h4 className="mb-2 text-xs font-medium text-muted-foreground uppercase tracking-wider">
                Komendy
              </h4>
              <div className="space-y-1">
                {filteredCommands.map((command, index) => {
                  const Icon = command.icon;
                  return (
                    <div
                      key={command.id}
                      className={cn(
                        "flex items-center justify-between rounded-lg px-3 py-2 text-sm cursor-pointer transition-colors",
                        index === selectedIndex
                          ? "bg-accent text-accent-foreground"
                          : "hover:bg-accent/50"
                      )}
                    >
                      <div className="flex items-center">
                        <Icon className="mr-3 h-4 w-4 opacity-50" />
                        <div>
                          <div className="font-medium">{command.title}</div>
                          <div className="text-xs text-muted-foreground">
                            {command.description}
                          </div>
                        </div>
                      </div>
                      {command.shortcut && (
                        <Badge variant="outline" className="text-xs">
                          {command.shortcut}
                        </Badge>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* No results */}
          {filteredCommands.length === 0 && filteredRecent.length === 0 && query !== '' && (
            <div className="text-center py-8 text-muted-foreground">
              <Search className="mx-auto h-8 w-8 mb-2 opacity-50" />
              <p>Brak wyników dla "{query}"</p>
            </div>
          )}
        </div>

        <div className="border-t border-glass-border px-4 py-2">
          <div className="flex text-xs text-muted-foreground">
            <span className="flex items-center">
              <Badge variant="outline" className="mr-1">↑↓</Badge>
              Nawiguj
            </span>
            <span className="flex items-center ml-4">
              <Badge variant="outline" className="mr-1">⏎</Badge>
              Wybierz
            </span>
            <span className="flex items-center ml-4">
              <Badge variant="outline" className="mr-1">ESC</Badge>
              Zamknij
            </span>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}