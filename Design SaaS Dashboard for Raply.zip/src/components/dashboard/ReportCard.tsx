import { useState } from 'react';
import { Calendar, Eye, Download, Sparkles, MoreVertical } from 'lucide-react';
import { cn } from '../ui/utils';
import { Badge } from '../ui/badge';
import { Button } from '../ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

interface ReportCardProps {
  id: string;
  title: string;
  description: string;
  thumbnail: string;
  date: string;
  type: 'facebook' | 'google' | 'instagram' | 'linkedin';
  aiGenerated?: boolean;
  views?: number;
}

const typeColors = {
  facebook: 'bg-blue-500',
  google: 'bg-red-500',
  instagram: 'bg-pink-500',
  linkedin: 'bg-blue-600',
};

const typeLabels = {
  facebook: 'Facebook Ads',
  google: 'Google Ads',
  instagram: 'Instagram',
  linkedin: 'LinkedIn',
};

export function ReportCard({ 
  id, 
  title, 
  description, 
  thumbnail, 
  date, 
  type, 
  aiGenerated = false,
  views = 0 
}: ReportCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className={cn(
        "glass rounded-3xl border border-glass-border transition-all duration-300 group cursor-pointer",
        "hover:scale-105 hover:glow hover:-translate-y-1"
      )}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Thumbnail */}
      <div className="relative overflow-hidden rounded-t-3xl">
        <div 
          className="h-40 bg-cover bg-center transition-transform duration-300 group-hover:scale-110"
          style={{ backgroundImage: `url(${thumbnail})` }}
        >
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
          
          {/* Type badge */}
          <div className="absolute top-3 left-3">
            <Badge className={cn(typeColors[type], "text-white border-0")}>
              {typeLabels[type]}
            </Badge>
          </div>

          {/* AI badge */}
          {aiGenerated && (
            <div className="absolute top-3 right-3">
              <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
                <Sparkles className="w-3 h-3 mr-1" />
                AI
              </Badge>
            </div>
          )}

          {/* Hover overlay */}
          <div className={cn(
            "absolute inset-0 bg-black/40 flex items-center justify-center transition-opacity duration-300",
            isHovered ? "opacity-100" : "opacity-0"
          )}>
            <Button size="sm" className="bg-white/20 backdrop-blur-sm border border-white/30 text-white hover:bg-white/30">
              <Eye className="w-4 h-4 mr-2" />
              Zobacz raport
            </Button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-3">
          <h3 className="font-semibold line-clamp-2 group-hover:text-primary transition-colors">
            {title}
          </h3>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="glass border-glass-border">
              <DropdownMenuItem>
                <Eye className="mr-2 h-4 w-4" />
                Zobacz
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Download className="mr-2 h-4 w-4" />
                Pobierz
              </DropdownMenuItem>
              <DropdownMenuItem className="text-destructive focus:text-destructive">
                Usuń
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        <p className="text-muted-foreground text-sm mb-4 line-clamp-2">
          {description}
        </p>

        <div className="flex items-center justify-between text-sm text-muted-foreground">
          <div className="flex items-center">
            <Calendar className="w-4 h-4 mr-1" />
            {date}
          </div>
          
          {views > 0 && (
            <div className="flex items-center">
              <Eye className="w-4 h-4 mr-1" />
              {views}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}