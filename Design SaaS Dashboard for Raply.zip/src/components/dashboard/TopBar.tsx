import { useState } from 'react';
import { 
  Search, 
  Bell, 
  Sun, 
  Moon, 
  User,
  Command,
  ChevronDown,
  Settings
} from 'lucide-react';
import { cn } from '../ui/utils';
import { Button } from '../ui/button';
import { Badge } from '../ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '../ui/avatar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '../ui/dropdown-menu';

interface TopBarProps {
  darkMode: boolean;
  onThemeToggle: () => void;
  sidebarCollapsed: boolean;
}

export function TopBar({ darkMode, onThemeToggle, sidebarCollapsed }: TopBarProps) {
  const [searchFocused, setSearchFocused] = useState(false);

  return (
    <div 
      className={cn(
        "fixed top-0 right-0 h-16 glass border-b border-glass-border z-30 transition-all duration-300",
        sidebarCollapsed ? "left-16" : "left-60"
      )}
    >
      <div className="flex items-center justify-between h-full px-6">
        {/* Search */}
        <div className="flex-1 max-w-md">
          <div 
            className={cn(
              "relative group transition-all duration-200",
              searchFocused && "scale-105"
            )}
          >
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              {searchFocused ? (
                <Command className="h-4 w-4 text-primary" />
              ) : (
                <Search className="h-4 w-4 text-muted-foreground" />
              )}
            </div>
            <input
              type="text"
              placeholder="Szukaj lub wpisz ⌘K..."
              className={cn(
                "block w-full pl-10 pr-3 py-2 glass rounded-xl transition-all duration-200",
                "focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary/20",
                searchFocused && "glow"
              )}
              onFocus={() => setSearchFocused(true)}
              onBlur={() => setSearchFocused(false)}
            />
            <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
              <kbd className="inline-flex items-center rounded border border-border px-1 font-mono text-xs text-muted-foreground">
                ⌘K
              </kbd>
            </div>
          </div>
        </div>

        {/* Right side */}
        <div className="flex items-center space-x-4">
          {/* Theme toggle */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onThemeToggle}
            className="relative overflow-hidden hover:bg-sidebar-accent hover:glow"
          >
            {darkMode ? (
              <Sun className="h-4 w-4 rotate-0 scale-100 transition-all" />
            ) : (
              <Moon className="h-4 w-4 rotate-0 scale-100 transition-all" />
            )}
          </Button>

          {/* Notifications */}
          <Button
            variant="ghost"
            size="sm"
            className="relative hover:bg-sidebar-accent hover:glow"
          >
            <Bell className="h-4 w-4" />
            <Badge 
              className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 bg-destructive text-destructive-foreground"
            >
              3
            </Badge>
          </Button>

          {/* User menu */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button 
                variant="ghost" 
                className="flex items-center space-x-2 hover:bg-sidebar-accent hover:glow"
              >
                <Avatar className="h-8 w-8">
                  <AvatarImage src="/placeholder-avatar.jpg" alt="User" />
                  <AvatarFallback className="bg-primary text-primary-foreground">
                    <User className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col items-start">
                  <span className="text-sm font-medium">Sarah Chen</span>
                  <span className="text-xs text-muted-foreground">Kierownik ds. marketingu</span>
                </div>
                <ChevronDown className="h-4 w-4 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent 
              align="end" 
              className="w-56 glass border-glass-border"
            >
              <DropdownMenuItem>
                <User className="mr-2 h-4 w-4" />
                Profil
              </DropdownMenuItem>
              <DropdownMenuItem>
                <Settings className="mr-2 h-4 w-4" />
                Ustawienia
              </DropdownMenuItem>
              <DropdownMenuSeparator />
              <DropdownMenuItem className="text-destructive focus:text-destructive">
                Wyloguj się
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}