import { useState } from 'react';
import Group3 from '../../imports/Group3';
import { 
  LayoutDashboard, 
  FileText, 
  BarChart3, 
  Settings, 
  Zap, 
  Users,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { cn } from '../ui/utils';

interface SidebarProps {
  collapsed: boolean;
  onCollapse: (collapsed: boolean) => void;
}

const navigation = [
  { name: 'Panel główny', href: '#', icon: LayoutDashboard, current: true },
  { name: 'Raporty', href: '#', icon: FileText, current: false },
  { name: 'Analityka', href: '#', icon: BarChart3, current: false },
  { name: 'Automatyzacja', href: '#', icon: Zap, current: false },
  { name: 'Zespół', href: '#', icon: Users, current: false },
  { name: 'Ustawienia', href: '#', icon: Settings, current: false },
];

export function Sidebar({ collapsed, onCollapse }: SidebarProps) {
  return (
    <div 
      className={cn(
        "fixed left-0 top-0 h-full glass border-r border-glass-border transition-all duration-300 z-40",
        collapsed ? "w-16" : "w-60"
      )}
    >
      {/* Header */}
      <div className="flex items-center justify-between border-b border-glass-border p-[16px] mx-[-14px] my-[0px] rounded-[0px]">
        <div className="flex items-center justify-center w-full p-[0px] rounded-[0px] m-[0px] px-[16px] py-[0px]">
          <div className="w-8 h-8 flex-shrink-0">
            <Group3 />
          </div>
        </div>
        {!collapsed && (
          <button
            onClick={() => onCollapse(true)}
            className="p-1 rounded-lg hover:bg-sidebar-accent transition-colors absolute right-4"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Expand button for collapsed state */}
      {collapsed && (
        <button
          onClick={() => onCollapse(false)}
          className="absolute -right-3 top-20 w-6 h-6 bg-primary rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
        >
          <ChevronRight className="w-3 h-3 text-primary-foreground" />
        </button>
      )}

      {/* Navigation */}
      <nav className="mt-8 space-y-1 px-3">
        {navigation.map((item) => {
          const Icon = item.icon;
          return (
            <a
              key={item.name}
              href={item.href}
              className={cn(
                "flex items-center px-3 py-2 rounded-xl transition-all duration-200 group",
                item.current
                  ? "bg-primary text-primary-foreground shadow-lg glow"
                  : "text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
                collapsed && "justify-center"
              )}
            >
              <Icon 
                className={cn(
                  "w-5 h-5 transition-transform group-hover:scale-110",
                  !collapsed && "mr-3"
                )} 
              />
              {!collapsed && (
                <span className="font-medium">{item.name}</span>
              )}
            </a>
          );
        })}
      </nav>

      {/* AI Assistant */}
      {!collapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="glass rounded-xl p-4 border border-glass-border">
            <div className="flex items-center mb-2">
              <div className="w-8 h-8 bg-gradient-to-br from-primary to-accent rounded-lg flex items-center justify-center">
                <Zap className="w-4 h-4 text-white" />
              </div>
              <div className="ml-3">
                <p className="font-medium">Asystent AI</p>
                <p className="text-xs text-muted-foreground">Gotowy do pomocy</p>
              </div>
            </div>
            <button className="w-full bg-primary/10 hover:bg-primary/20 text-primary py-2 px-3 rounded-lg transition-colors">
              Zapytaj Raply AI
            </button>
          </div>
        </div>
      )}
    </div>
  );
}