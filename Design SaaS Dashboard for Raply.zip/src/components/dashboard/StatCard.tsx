import { LucideIcon, TrendingUp, TrendingDown } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { cn } from '../ui/utils';

interface ChartDataPoint {
  name: string;
  value: number;
  date?: string;
}

interface PlatformData {
  name: string;
  value: number;
  color: string;
}

interface StatCardProps {
  title: string;
  value: string;
  change: number;
  icon: LucideIcon;
  gradient: string;
  size?: 'default' | 'large';
  sparklineData?: number[];
  chartData?: ChartDataPoint[];
  platformData?: PlatformData[];
}

export function StatCard({ 
  title, 
  value, 
  change, 
  icon: Icon, 
  gradient,
  size = 'default',
  sparklineData = [],
  chartData = [],
  platformData = []
}: StatCardProps) {
  const isPositive = change > 0;

  // Simple sparkline SVG
  const generateSparkline = (data: number[]) => {
    if (data.length < 2) return '';
    
    const max = Math.max(...data);
    const min = Math.min(...data);
    const range = max - min;
    
    const points = data.map((value, index) => {
      const x = (index / (data.length - 1)) * 100;
      const y = range === 0 ? 50 : ((max - value) / range) * 60 + 20;
      return `${x},${y}`;
    }).join(' ');
    
    return `M ${points.replace(/,/g, ' L ')}`;
  };

  return (
    <div 
      className={cn(
        "glass rounded-3xl p-6 border border-glass-border transition-all duration-300 hover:scale-105 hover:glow group relative overflow-hidden",
        size === 'large' && "col-span-2 row-span-2"
      )}
    >
      {/* Gradient overlay for better contrast */}
      <div 
        className="absolute inset-0 rounded-3xl opacity-90"
        style={{ background: gradient }}
      />
      
      {/* Dark overlay for text readability */}
      <div className="absolute inset-0 bg-black/20 rounded-[24px]" />
      
      {/* Content */}
      <div className="relative z-10 px-[-1px] py-[0px] mx-[-14px] my-[0px]">
        <div className="flex items-center justify-between mb-[16px] px-[-9px] py-[0px] mt-[0px] mr-[0px] ml-[0px]">
          <div className={cn(
            "p-3 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/30 group-hover:scale-110 transition-transform",
            size === 'large' && "p-4"
          )}>
            <Icon className={cn(
              "text-white drop-shadow-sm",
              size === 'large' ? "w-8 h-8" : "w-6 h-6"
            )} />
          </div>
          
          <div className={cn(
            "flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-medium backdrop-blur-sm border shadow-sm",
            isPositive 
              ? "bg-green-100/90 text-green-800 border-green-200/50" 
              : "bg-red-100/90 text-red-800 border-red-200/50"
          )}>
            {isPositive ? (
              <TrendingUp className="w-3 h-3" />
            ) : (
              <TrendingDown className="w-3 h-3" />
            )}
            <span>{Math.abs(change)}%</span>
          </div>
        </div>

        <div className="space-y-2">
          <h3 className={cn(
            "text-white font-medium drop-shadow-sm",
            size === 'large' ? "text-lg" : "text-sm"
          )}>
            {title}
          </h3>
          <p className={cn(
            "text-white font-bold drop-shadow-md",
            size === 'large' ? "text-4xl" : "text-2xl"
          )}>
            {value}
          </p>
        </div>

        {/* ROAS Chart for large card */}
        {title === 'ROAS' && size === 'large' && chartData.length > 0 && (
          <div className="mt-6 space-y-4">
            {/* Main ROAS trend chart */}
            <div className="h-40">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={chartData}>
                  <XAxis 
                    dataKey="name" 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'rgba(255, 255, 255, 0.7)', fontSize: 12 }}
                  />
                  <YAxis 
                    axisLine={false}
                    tickLine={false}
                    tick={{ fill: 'rgba(255, 255, 255, 0.7)', fontSize: 12 }}
                    domain={['dataMin - 0.2', 'dataMax + 0.2']}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="value" 
                    stroke="rgba(255, 255, 255, 0.9)" 
                    strokeWidth={3}
                    dot={{ fill: 'white', strokeWidth: 2, r: 4 }}
                    activeDot={{ r: 6, fill: 'white' }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
            
            {/* Platform breakdown */}
            {platformData.length > 0 && (
              <div className="flex items-center justify-between">
                <div className="space-y-2">
                  <h4 className="text-white/90 text-sm font-medium">Breakdown po platformach</h4>
                  <div className="space-y-1">
                    {platformData.map((platform) => (
                      <div key={platform.name} className="flex items-center space-x-2">
                        <div 
                          className="w-3 h-3 rounded-full" 
                          style={{ backgroundColor: platform.color }}
                        />
                        <span className="text-white/80 text-xs">{platform.name}</span>
                        <span className="text-white font-medium text-xs">{platform.value}x</span>
                      </div>
                    ))}
                  </div>
                </div>
                
                <div className="w-20 h-20">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={platformData}
                        dataKey="value"
                        nameKey="name"
                        cx="50%"
                        cy="50%"
                        innerRadius={15}
                        outerRadius={35}
                        strokeWidth={0}
                      >
                        {platformData.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Regular Sparkline for other cards */}
        {(title !== 'ROAS' || size !== 'large') && sparklineData.length > 0 && (
          <div className="mt-4">
            <svg 
              className="w-full h-16 opacity-80" 
              viewBox="0 0 100 80" 
              preserveAspectRatio="none"
            >
              <path
                d={generateSparkline(sparklineData)}
                fill="none"
                stroke="rgba(255, 255, 255, 0.9)"
                strokeWidth="2"
                vectorEffect="non-scaling-stroke"
                className="drop-shadow-sm"
              />
              <defs>
                <linearGradient id={`gradient-${title}`} x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="rgba(255, 255, 255, 0.4)" />
                  <stop offset="100%" stopColor="rgba(255, 255, 255, 0)" />
                </linearGradient>
              </defs>
              <path
                d={`${generateSparkline(sparklineData)} L 100,80 L 0,80 Z`}
                fill={`url(#gradient-${title})`}
              />
            </svg>
          </div>
        )}

        {size === 'large' && (
          <div className="mt-6 flex items-center justify-between text-white/90 text-sm font-medium drop-shadow-sm">
            <span>Ostatnie 30 dni</span>
            <span>{isPositive ? 'Trend wzrostowy' : 'Wymaga uwagi'}</span>
          </div>
        )}
      </div>
    </div>
  );
}