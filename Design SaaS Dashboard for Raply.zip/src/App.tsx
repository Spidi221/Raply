import { useState, useEffect } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Users, 
  MousePointer,
  Plus
} from 'lucide-react';
import { Sidebar } from './components/dashboard/Sidebar';
import { TopBar } from './components/dashboard/TopBar';
import { StatCard } from './components/dashboard/StatCard';
import { ReportCard } from './components/dashboard/ReportCard';
import { FloatingActionButton } from './components/dashboard/FloatingActionButton';
import { CommandPalette } from './components/dashboard/CommandPalette';
import { cn } from './components/ui/utils';
import { ImageWithFallback } from './components/figma/ImageWithFallback';

// Dane testowe
const stats = [
  {
    title: 'ROAS',
    value: '4.2x',
    change: 12.5,
    icon: DollarSign,
    gradient: 'linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)',
    sparklineData: [3.2, 3.5, 3.8, 4.1, 4.0, 4.2, 4.3, 4.2],
    chartData: [
      { name: '1 Gru', value: 3.8 },
      { name: '5 Gru', value: 4.1 },
      { name: '10 Gru', value: 3.9 },
      { name: '15 Gru', value: 4.3 },
      { name: '20 Gru', value: 4.0 },
      { name: '25 Gru', value: 4.5 },
      { name: '30 Gru', value: 4.2 },
    ],
    platformData: [
      { name: 'Facebook', value: 4.8, color: '#1877F2' },
      { name: 'Google', value: 3.9, color: '#4285F4' },
      { name: 'Instagram', value: 3.7, color: '#E4405F' },
    ],
  },
  {
    title: 'Wydatki na reklamy',
    value: '127,4K zł',
    change: 8.2,
    icon: TrendingUp,
    gradient: 'linear-gradient(135deg, #10B981 0%, #059669 100%)',
    sparklineData: [105, 112, 118, 123, 125, 127, 129, 127],
  },
  {
    title: 'Konwersje',
    value: '2 847',
    change: 15.3,
    icon: Users,
    gradient: 'linear-gradient(135deg, #F59E0B 0%, #D97706 100%)',
    sparklineData: [2200, 2350, 2500, 2650, 2750, 2800, 2850, 2847],
  },
  {
    title: 'CTR',
    value: '3,24%',
    change: -2.1,
    icon: MousePointer,
    gradient: 'linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)',
    sparklineData: [3.5, 3.4, 3.3, 3.2, 3.1, 3.2, 3.3, 3.24],
  },
];

const reports = [
  {
    id: '1',
    title: 'Wyniki kampanii Facebook Q4 2024',
    description: 'Kompleksowa analiza skuteczności reklam na Facebooku wraz z wglądem w odbiorców i rekomendacjami optymalizacji.',
    thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=400&h=200&fit=crop',
    date: '15 grudnia 2024',
    type: 'facebook' as const,
    aiGenerated: true,
    views: 247,
  },
  {
    id: '2',
    title: 'Analiza ROI Google Ads',
    description: 'Szczegółowa analiza zwrotu z inwestycji w Google Ads z podziałem na wydajność słów kluczowych.',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=200&fit=crop',
    date: '12 grudnia 2024',
    type: 'google' as const,
    views: 189,
  },
  {
    id: '3',
    title: 'Wyniki kampanii Instagram Stories',
    description: 'Metryki wydajności kampanii reklamowej Instagram Stories z analizą zaangażowania.',
    thumbnail: 'https://images.unsplash.com/photo-1611605698335-8b1569810432?w=400&h=200&fit=crop',
    date: '10 grudnia 2024',
    type: 'instagram' as const,
    aiGenerated: true,
    views: 156,
  },
  {
    id: '4',
    title: 'Generowanie leadów B2B LinkedIn',
    description: 'Analiza skuteczności reklam LinkedIn w kampaniach generowania leadów B2B.',
    thumbnail: 'https://images.unsplash.com/photo-1664575602554-2087b04935a5?w=400&h=200&fit=crop',
    date: '8 grudnia 2024',
    type: 'linkedin' as const,
    views: 203,
  },
  {
    id: '5',
    title: 'Raport atrybucji wieloplatformowej',
    description: 'Analiza atrybucji multi-touch w kampaniach Facebook, Google i Instagram.',
    thumbnail: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=400&h=200&fit=crop',
    date: '5 grudnia 2024',
    type: 'facebook' as const,
    aiGenerated: true,
    views: 312,
  },
  {
    id: '6',
    title: 'Wyniki sezonu świątecznego',
    description: 'Specjalny raport obejmujący wydajność kampanii Black Friday i Cyber Monday.',
    thumbnail: 'https://images.unsplash.com/photo-1607400201515-c1af3ff07e6c?w=400&h=200&fit=crop',
    date: '1 grudnia 2024',
    type: 'google' as const,
    views: 428,
  },
];

export default function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [commandPaletteOpen, setCommandPaletteOpen] = useState(false);

  // Theme toggle
  const toggleTheme = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setCommandPaletteOpen(!commandPaletteOpen);
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [commandPaletteOpen]);

  return (
    <div className="min-h-screen bg-background gradient-mesh">
      {/* Sidebar */}
      <Sidebar 
        collapsed={sidebarCollapsed} 
        onCollapse={setSidebarCollapsed} 
      />

      {/* Top Bar */}
      <TopBar 
        darkMode={darkMode}
        onThemeToggle={toggleTheme}
        sidebarCollapsed={sidebarCollapsed}
      />

      {/* Main Content */}
      <main 
        className={cn(
          "pt-16 transition-all duration-300",
          sidebarCollapsed ? "ml-16" : "ml-60"
        )}
      >
        <div className="p-8 space-y-8">
          {/* Sekcja powitalna */}
          <div className="space-y-2">
            <h1 className="text-3xl font-bold">Witaj ponownie, Sarah! 👋</h1>
            <p className="text-muted-foreground">
              Oto co dzieje się dzisiaj z Twoimi kampaniami reklamowymi.
            </p>
          </div>

          {/* Stats Grid - Bento Layout */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <StatCard
                key={stat.title}
                title={stat.title}
                value={stat.value}
                change={stat.change}
                icon={stat.icon}
                gradient={stat.gradient}
                size={index === 0 ? 'large' : 'default'}
                sparklineData={stat.sparklineData}
                chartData={(stat as any).chartData}
                platformData={(stat as any).platformData}
              />
            ))}
          </div>

          {/* Sekcja analiz AI */}
          <div className="glass rounded-3xl p-6 border border-glass-border">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center mr-4">
                <Plus className="w-5 h-5 text-white" />
              </div>
              <div>
                <h2 className="text-xl font-semibold">Analizy AI</h2>
                <p className="text-muted-foreground">Napędzane przez Raply AI</p>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="glass rounded-2xl p-4 border border-glass-border">
                <p className="mb-3">
                  🎯 <strong>Możliwość optymalizacji:</strong> Twoje kampanie Facebook pokazują 23% wyższy CTR w weekendy. 
                  Rozważ zwiększenie budżetów weekendowych o 15-20%.
                </p>
                <div className="flex space-x-2">
                  <button className="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm hover:bg-primary/20 transition-colors">
                    Zastosuj sugestię
                  </button>
                  <button className="px-3 py-1 bg-muted/50 text-muted-foreground rounded-full text-sm hover:bg-muted transition-colors">
                    Odrzuć
                  </button>
                </div>
              </div>

              <div className="glass rounded-2xl p-4 border border-glass-border">
                <p className="mb-3">
                  📊 <strong>Alert wydajności:</strong> ROAS Google Ads spadł o 8% w tym tygodniu. 
                  Zaleca się przegląd stawek za słowa kluczowe i wstrzymanie słabo działających grup reklam.
                </p>
                <div className="flex space-x-2">
                  <button className="px-3 py-1 bg-warning/10 text-warning rounded-full text-sm hover:bg-warning/20 transition-colors">
                    Zobacz szczegóły
                  </button>
                  <button className="px-3 py-1 bg-muted/50 text-muted-foreground rounded-full text-sm hover:bg-muted transition-colors">
                    Odrzuć
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Sekcja raportów */}
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Najnowsze raporty</h2>
              <button className="text-primary hover:text-primary/80 font-medium">
                Zobacz wszystkie raporty →
              </button>
            </div>

            {/* Masonry Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {reports.map((report) => (
                <ReportCard
                  key={report.id}
                  id={report.id}
                  title={report.title}
                  description={report.description}
                  thumbnail={report.thumbnail}
                  date={report.date}
                  type={report.type}
                  aiGenerated={report.aiGenerated}
                  views={report.views}
                />
              ))}
            </div>
          </div>
        </div>
      </main>

      {/* Floating Action Button */}
      <FloatingActionButton />

      {/* Command Palette */}
      <CommandPalette 
        open={commandPaletteOpen}
        onOpenChange={setCommandPaletteOpen}
      />
    </div>
  );
}