import svgPaths from "./svg-1fsnefpeq4";

function Group() {
  return (
    <div className="absolute inset-[19.56%_59.23%_20.5%_21.36%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 128 128">
        <g id="Group">
          <path d={svgPaths.p1b08ab90} fill="var(--fill-0, #0E3B7A)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group1() {
  return (
    <div className="absolute contents inset-[19.56%_59.23%_20.5%_21.36%]" data-name="Group">
      <Group />
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute contents inset-[19.56%_59.23%_20.5%_21.36%]" data-name="Group">
      <Group1 />
    </div>
  );
}

function Group4() {
  return (
    <div className="absolute inset-[19.56%_34.38%_1.05%_44.12%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 142 169">
        <g id="Group">
          <path d={svgPaths.p8f7d600} fill="url(#paint0_linear_1_44)" id="Vector" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_44" x1="2.79992" x2="130.3" y1="5.97681" y2="107.477">
            <stop stopColor="#0E3B7A" />
            <stop offset="1" stopColor="#1589B2" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group5() {
  return (
    <div className="absolute contents inset-[19.56%_34.38%_1.05%_44.12%]" data-name="Group">
      <Group4 />
    </div>
  );
}

function Group6() {
  return (
    <div className="absolute contents inset-[19.56%_34.38%_1.05%_44.12%]" data-name="Group">
      <Group5 />
    </div>
  );
}

function Group7() {
  return (
    <div className="absolute bottom-[21.56%] left-[68.04%] right-[24.23%] top-0" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 51 167">
        <g id="Group">
          <path d={svgPaths.p183b7980} fill="url(#paint0_linear_1_38)" id="Vector" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_38" x1="-158.784" x2="50.2156" y1="44.9975" y2="161.498">
            <stop stopColor="#0E3B7A" />
            <stop offset="0.763532" stopColor="#1589B2" />
            <stop offset="1" stopColor="#17A1C3" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group8() {
  return (
    <div className="absolute bottom-[21.56%] contents left-[68.04%] right-[24.23%] top-0" data-name="Group">
      <Group7 />
    </div>
  );
}

function Group9() {
  return (
    <div className="absolute bottom-[21.56%] contents left-[68.04%] right-[24.23%] top-0" data-name="Group">
      <Group8 />
    </div>
  );
}

function Group10() {
  return (
    <div className="absolute bottom-0 left-[76.96%] right-0 top-[20.62%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 152 169">
        <g id="Group">
          <path d={svgPaths.pdd87b00} fill="url(#paint0_linear_1_41)" id="Vector" />
        </g>
        <defs>
          <linearGradient gradientUnits="userSpaceOnUse" id="paint0_linear_1_41" x1="-211.837" x2="98.1633" y1="5.72681" y2="132.727">
            <stop stopColor="#0E3B7A" />
            <stop offset="0.718417" stopColor="#17A1C3" />
            <stop offset="1" stopColor="#1AC9E0" />
          </linearGradient>
        </defs>
      </svg>
    </div>
  );
}

function Group11() {
  return (
    <div className="absolute bottom-0 contents left-[76.96%] right-0 top-[20.62%]" data-name="Group">
      <Group10 />
    </div>
  );
}

function Group12() {
  return (
    <div className="absolute bottom-0 contents left-[76.96%] right-0 top-[20.62%]" data-name="Group">
      <Group11 />
    </div>
  );
}

function Group13() {
  return (
    <div className="absolute bottom-[21.41%] left-0 right-[78.71%] top-[3.53%]" data-name="Group">
      <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 140 160">
        <g id="Group">
          <path d={svgPaths.p34aca1f0} fill="var(--fill-0, #0E3B7A)" id="Vector" />
        </g>
      </svg>
    </div>
  );
}

function Group14() {
  return (
    <div className="absolute bottom-[21.41%] contents left-0 right-[78.71%] top-[3.53%]" data-name="Group">
      <Group13 />
    </div>
  );
}

function Group15() {
  return (
    <div className="absolute bottom-[21.41%] contents left-0 right-[78.71%] top-[3.53%]" data-name="Group">
      <Group14 />
    </div>
  );
}

export default function Group3() {
  return (
    <div className="relative size-full px-[48px] py-[0px] mx-[-89px] my-[0px]">
      <Group2 />
      <Group6 />
      <Group9 />
      <Group12 />
      <Group15 />
    </div>
  );
}